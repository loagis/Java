package org.bonn.se.uebung1.ws18.control;

interface Translator {
	
	public double version = 1.0; 
	
	public String translateNumber( int number );

} 
 