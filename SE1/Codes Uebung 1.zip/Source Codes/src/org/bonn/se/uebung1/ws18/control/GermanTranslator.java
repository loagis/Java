package org.bonn.se.uebung1.ws18.control;

public class GermanTranslator implements Translator {

	public String translateNumber( int number ) {
		
	}
	 
	@Override
	public void printAuthorInfo() {
		System.out.println("GermanTranslator c/o 2018 by HBRS");
	}
	
}
